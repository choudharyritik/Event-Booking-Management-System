/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
     "./pages/login.{js,jsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

